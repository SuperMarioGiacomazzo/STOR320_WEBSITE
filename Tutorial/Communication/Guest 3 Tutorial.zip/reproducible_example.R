# This script demonstrates an example of a reproducible example

library(tidyverse)
library(MASS)

# attempt to select a column from a data frame
select(mtcars, mpg)


